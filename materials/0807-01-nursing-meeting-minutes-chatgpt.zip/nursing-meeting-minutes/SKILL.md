---
name: nursing-meeting-minutes
description: Use this skill when I ask you to turn a nursing department meeting (護理長座談會、護理部會議等) into a formal Word-style meeting minutes document, and I provide (or describe) a meeting minutes template. Do NOT use this skill for casual note-taking or for meetings unrelated to nursing department management.
---

GOAL
Produce a formal nursing department meeting minutes document that exactly follows the
structure of a template I provide (or, if no template exists yet, a reasonable formal
default structure), with every section heading preserved and no invented content.

REQUIRED INPUTS
- 會議紀錄範本 (a previous meeting minutes file, or a description of its section headings,
  numbering style — 壹貳參肆 / 一二三 — table layouts, and any fixed footer/page-number style)
- 會議基本資料：會議名稱、時間、地點、主席、記錄
- 逐字稿 (transcript), OR — if none exists — my willingness to answer one question per
  template section
- (optional) 會議照片，only if the template has a "會議照片" section

WORKFLOW
1. Ask for the meeting minutes template first, before anything else. If I say a template
   was already given earlier in this conversation, reuse the structure already analyzed —
   do not ask me to re-upload it.
   - Note down: title format, section numbering style (壹貳參肆 for top-level, 一二三 for
     sub-items, or whatever the template actually uses), which sections are fixed vs.
     which vary meeting to meeting, table layouts, and footer/page-number style.
2. Ask for the five basic fields: 會議名稱 / 時間 / 地點 / 主席 / 記錄. Echo them back for
   confirmation before moving on.
3. Ask for the transcript.
   - If I say I have no transcript, switch to the "no-transcript path": go through every
     single dynamic section heading found in the template, one at a time, and ask me what
     this meeting's content for that section is. Do not skip a section because it "seems
     unlikely to apply" — ask about literally every section. If I answer "無" for a
     section, keep the section heading in the final document but write "無" as its content;
     never delete a heading just because there's no content under it.
   - If a transcript is provided, extract: attendees (only if explicitly named/counted in
     the transcript), discussion points per section, decisions, action items with owner and
     deadline. Skip filler speech (um, repeated words, off-topic chat).
   - Anything unclear, incomplete, or ambiguous in the transcript or in my answers (missing
     owner, missing deadline, unclear speaker, ambiguous scope like an unqualified "無")
     must be flagged as "未確認，請覆核" or clarified with a follow-up question — never
     filled in with a plausible-sounding guess.
4. Before producing the file, summarize the whole draft as plain text/markdown in the chat
   and ask me to confirm or correct it. Do not generate the final file until I confirm.
5. If the template has a 會議照片 section, ask whether I want to include photos this time
   before finalizing. If I say no, leave that section's heading with "無" as content
   (consistent with rule in step 3), not an empty placeholder box.
6. Once I confirm, produce the final document (Word-style formatting: use whatever document
   creation capability you have — e.g. Canvas or code interpreter with python-docx — to
   match the template's structure). Default styling if no template details are given: plain
   centered bold title with NO shading/background color, section titles unshaded, page
   number in the footer. Do not add a colored background to the title unless I explicitly
   ask for one.

OUTPUT FORMAT
- Step 4 output: a plain-text/markdown recap of the full meeting minutes content, organized
  by the template's own section headings, with "未確認，請覆核" flags where relevant.
- Final output (after my confirmation): a downloadable formatted document that mirrors the
  template's title format, section numbering, and table layouts, with every template
  section heading present even when its content is "無".

RULES
- Never invent data, decisions, attendee names, numbers, or dates that are not explicitly
  in the transcript or in my direct answers.
- Never delete a section heading just because there's no content for it this time — the
  heading stays, the content becomes "無".
- Never skip asking about a section on your own judgment ("this one probably doesn't
  apply") — ask about every section from the template.
- Never move to the final document step without my explicit confirmation of the Step 4
  recap.
- Titles/headings default to no background shading unless I ask for it, even if a
  previous template file had shading.
- If my answer to "無" is ambiguous in scope (e.g., could mean "just this section" or "all
  remaining sections"), ask me to clarify the scope before proceeding — don't guess.

EXAMPLE
Input (no-transcript path, one section):
我：一、專題演講 講題：AI工作坊 講者：邱于容

Strong output (Step 4 recap, excerpt):
一、專題演講
- 講題：AI工作坊
- 講者：邱于容
（其餘章節待確認...）

REVIEW CHECKLIST
- Did I ask about every section in the template, not just the ones the user mentioned
  unprompted?
- Does every template section heading still appear in the draft, even the ones marked
  "無"?
- Did I flag every incomplete or ambiguous item as "未確認，請覆核" instead of guessing?
- Did I get explicit confirmation on the Step 4 recap before producing the final file?
- Does the title avoid background shading unless the user asked for it?
